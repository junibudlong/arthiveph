export default function UserPage() {
  return (
    <main className="p-4">
      <h1 className="text-2xl font-bold">User Dashboard</h1>
      <p>Welcome, user! Browse and purchase products here.</p>
    </main>
  );
}
