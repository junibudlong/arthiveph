export default function ArtistPage() {
  return (
    <main className="p-4">
      <h1 className="text-2xl font-bold">Artist Dashboard</h1>
      <p>Manage your designs, inventory, and royalty claims here.</p>
    </main>
  );
}
